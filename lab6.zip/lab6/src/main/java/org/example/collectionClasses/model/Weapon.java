package org.example.collectionClasses.model;

/**
 * Перечисление, представляющее типы оружия.
 *
 * @author ISyntax
 * @version 1.0
 */
public enum Weapon {
    BOLTGUN,
    MELTAGUN,
    BOLT_RIFLE,
    COMBI_PLASMA_GUN
}