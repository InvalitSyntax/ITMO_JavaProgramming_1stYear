/**
 * Пакет точки вхождения в программу
 *
 * @author ISyntax
 * @version 1.0
 */
package org.example.collectionClasses.main;